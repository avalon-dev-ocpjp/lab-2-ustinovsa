package ru.avalon.java.ocpjp.labs;

/**
 * Обрабатываемые приложением команды.
 */
public enum Commands {
    move,
    copy,
    exit
    /*
     * TODO №8 К текущему списку команд, добавьте ещё две команды
     */
}
